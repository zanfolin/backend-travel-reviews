repo: zanfolin/backend-travel-reviews
branch: main

## Last sync

date: 2026-08-29T11:29:00Z

### Updated in this project

- Criadas as 9 telas do app mobile do viajante (M1–M9) com estados de loading, vazio, erro e validação.
- Criadas as 7 telas do painel web do estabelecimento (W1–W7) com modal de exclusão, upload em progresso e toasts.
- Dados, enums e regras extraídos das migrations, do seed e do PROMPT_PROTOTIPO_TELAS.md do repositório.
- Cada tela traz anotação de rota, campos e regras da API para handoff.

## Screen map

| Tela do projeto | Arquivos do repositório |
| --- | --- |
| AccessTrip Mobile.dc.html · M1–M4 (onboarding, cadastro, código, login) | PROMPT_PROTOTIPO_TELAS.md, src/controllers/auth.controller.js, src/routes/auth.routes.js, database/migrations/20260829000001_create_users_table.js |
| AccessTrip Mobile.dc.html · M5, M6 (feed e filtros) | PROMPT_PROTOTIPO_TELAS.md, README.md, src/routes/place.routes.js, database/migrations/20260829000002_create_places_table.js, database/seeds/01_initial_data.js |
| AccessTrip Mobile.dc.html · M7, M8 (detalhes e avaliação) | PROMPT_PROTOTIPO_TELAS.md, src/routes/review.routes.js, database/migrations/20260829000003_create_reviews_table.js, database/seeds/01_initial_data.js |
| AccessTrip Mobile.dc.html · M9 (perfil) | PROMPT_PROTOTIPO_TELAS.md, src/routes/user.routes.js, src/config/upload.js |
| AccessTrip Web.dc.html · W1, W2 (autenticação e verificação) | PROMPT_PROTOTIPO_TELAS.md, src/controllers/auth.controller.js, src/middlewares/auth.middleware.js |
| AccessTrip Web.dc.html · W3 (dashboard) | PROMPT_PROTOTIPO_TELAS.md, src/routes/business.routes.js, README.md |
| AccessTrip Web.dc.html · W4, W5 (locais e formulário) | PROMPT_PROTOTIPO_TELAS.md, src/routes/place.routes.js, database/migrations/20260829000002_create_places_table.js, src/config/upload.js |
| AccessTrip Web.dc.html · W6 (central de avaliações) | PROMPT_PROTOTIPO_TELAS.md, src/routes/review.routes.js |
| AccessTrip Web.dc.html · W7 (perfil corporativo) | PROMPT_PROTOTIPO_TELAS.md, src/routes/user.routes.js |
